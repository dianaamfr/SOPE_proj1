/**
 * @file simpledu.h
 * @author SOPE Group T02G05
 * @date 20 March 2020
 * @brief File containing simpledu headers 
 */

#ifndef SIMPLEDU
#define SIMPLEDU

/**
 * @brief Main function for simpledu command 
*/
int main(int argc, char * argv[], char * envp[]);

#endif
